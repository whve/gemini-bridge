# Discovering Regulatory Relationships Across 3D Genome Architecture and DNA Methylation (CARA-E2G)

**Standalone Computational Biology Research Repository — AI Science Arena (Task 02)**

## 1. Overview & Scientific Objective

This self-contained repository investigates whether integrating base-resolution **DNA methylation (WGBS)**, **3D chromatin interactions (Hi-C)**, and **1D chromatin activity / gene expression (DNase-seq, H3K27ac ChIP-seq, RNA-seq)** improves functional enhancer–gene (E–G) regulatory inference beyond established methods such as **Activity-by-Contact (ABC)** ([Fulco et al., 2019](https://pmc.ncbi.nlm.nih.gov/articles/PMC6886585/)) and **ENCODE-rE2G** ([Gschwind et al., 2023/2026](https://pmc.ncbi.nlm.nih.gov/articles/PMC10680627/)).

### Core Mechanistic Discovery
We identify and resolve a critical failure mechanism in multi-omics enhancer modeling: **Partially Methylated Domain (PMD) Confounding**. In human cancer and immortalized cell lines such as K562 (`ENCSR765JPC`), ~37.9% of candidate enhancer–gene pairs reside within megabase-scale, late-replicating, heterochromatic Partially Methylated Domains (PMDs; [Burger et al., 2013](https://pmc.ncbi.nlm.nih.gov/articles/PMC3763559/); [Fortin & Hansen, 2015](https://pmc.ncbi.nlm.nih.gov/articles/PMC4574526/)). Naive integration of focal enhancer unmethylation ($1 - M_{\text{focal}}$) conflates passive background hypomethylation inside repressed PMDs with active, transcription-factor-driven focal demethylation (Low-Methylated Regions, LMRs), causing 58.0% of top false-positive predictions to fall inside PMDs and yielding no statistically significant improvement over `ENCODE-rE2G-Core` ($\Delta\text{AUPRC} = +0.0044$, $p = 0.302$).

To overcome this failure mode and account for 3D contact sparsity at long genomic distances, we introduce **CARA-E2G** (*Context-Adjusted Reliability-Aware Enhancer-to-Gene* inference), which:
1. **Decouples active focal TF demethylation from regional PMD background** via $\Delta M_{\text{act}}(E) = r_m(E)\cdot \max(0, M_{\text{bg},50\text{kb}}(E) - M_{\text{focal}}(E))$ and models focal hypermethylation repression via $\Delta M_{\text{rep}}(E) = r_m(E)\cdot \max(0, M_{\text{focal}}(E) - M_{\text{bg},50\text{kb}}(E))$.
2. **Weights WGBS methylation features by binomial measurement reliability and CpG site density**: $r_m(E) = \frac{n_{\text{cov}}(E)}{n_{\text{cov}}(E) + \tau_m}\left(1 - e^{-k_E / k_0}\right)$.
3. **Applies Empirical-Bayes shrinkage to noisy 5-kb Hi-C contacts** toward the fractal-globule power-law distance prior $C_{\text{prior}}(d_{EG}) \propto d_{EG}^{-0.88}$ weighted by read depth reliability $r_c(E,G) = \frac{n_{\text{reads}}(E,G)}{n_{\text{reads}}(E,G) + \tau_c}$.
4. **Provides Laplace-approximated epistemic uncertainty $U(E,G)$** for risk-controlled abstention on under-sampled loci.

---

## 2. Repository Structure

```text
.
├── README.md                                  # Project overview, provenance, and reproduction guide
├── report.qmd                                 # Quarto scientific manuscript & research memo source
├── references.bib                             # BibTeX bibliography of primary literature & benchmarks
├── environment.yml                            # Conda environment specification
├── requirements.txt                           # Python pip dependencies
├── configs/
│   └── experiment_config.json                 # Data provenance accessions, hyperparameters, and seeds
├── data/
│   └── k562_crispr_multiomics_hg38.tsv.gz     # Harmonized K562 multi-omics CRISPRi dataset (N=10,375)
├── src/
│   ├── build_dataset.py                       # Data harmonization and multi-omics feature builder
│   ├── models.py                              # Staged baselines, CARA-E2G, and cluster bootstrap
│   ├── run_experiments.py                     # Executes Experiments 1-5 and logs all tables
│   └── generate_figures.py                    # Generates publication figures from saved results
├── results/
│   ├── dataset_summary.json                   # Summary statistics of the K562 benchmark
│   ├── exp1_modality_ablation.tsv             # Experiment 1: Staged baselines & modality ablation
│   ├── exp1_pr_curves.json                    # Exact Precision-Recall curve coordinates
│   ├── exp2_per_chromosome_performance.tsv    # Experiment 2: LOCO AUPRC across 23 chromosomes
│   ├── exp2_generalization_splits.tsv         # Experiment 2: Leakage audit & cross-screen transfer
│   ├── exp3_functional_validation_strata.tsv  # Experiment 3: HMD/PMD, mSTARR-seq & effect-size strata
│   ├── exp4a_distance_stratification.tsv      # Experiment 4A: Performance across 4 distance regimes
│   ├── exp4b_uncertainty_abstention.tsv       # Experiment 4B: Epistemic uncertainty abstention curve
│   ├── exp4c_robustness_sensitivity.tsv       # Experiment 4C: Hi-C noise, missing WGBS & imbalance
│   ├── exp5_canonical_loci_predictions.tsv    # Experiment 5: MYC, GATA1, HBG1/2, PRKAR2B, TFRC, NMU
│   ├── exp5_failure_audit_and_resources.json  # Experiment 5: Failure mechanism audit & runtime/memory
│   └── model_weights.json                     # Fitted standardized coefficients for rE2G vs CARA-E2G
└── figures/
    ├── fig1_pr_and_modality_ablation.png
    ├── fig2_generalization_and_chromosomes.png
    ├── fig3_functional_validation_and_pmd_audit.png
    ├── fig4_distance_robustness_and_uncertainty.png
    └── fig5_canonical_loci_and_feature_weights.png
```

---

## 3. Data Provenance & Accessions (K562, GRCh38 / hg38)

| Modality / Benchmark | Accession / Source | Assay & Processing Details | Reference |
| :--- | :--- | :--- | :--- |
| **CRISPRi Perturbation Benchmark** | `ENCSR998YDI` ([GitHub](https://github.com/EngreitzLab/CRISPR_comparison)) | 10,375 power-filtered ($\ge 80\%$) E–G pairs (472 positives, 9,903 negatives) across 618 loci on 23 chromosomes | [Gschwind et al. (2023/2026)](https://pmc.ncbi.nlm.nih.gov/articles/PMC10680627/); [Fulco et al. (2019)](https://pmc.ncbi.nlm.nih.gov/articles/PMC6886585/); [Gasperini et al. (2019)](https://pmc.ncbi.nlm.nih.gov/articles/PMC6690346/) |
| **Chromatin Accessibility** | `ENCSR000EOT` (`ENCFF257HEE`) | K562 DNase-seq normalized read density (RPM) at 500-bp candidate elements and promoters | [ENCODE Portal](https://www.encodeproject.org/experiments/ENCSR000EOT/) |
| **Histone H3K27ac** | `ENCSR000AKP` (`ENCFF232RQF`) | K562 H3K27ac ChIP-seq RPM at 500-bp candidate elements | [ENCODE Portal](https://www.encodeproject.org/experiments/ENCSR000AKP/) |
| **3D Chromatin Contact** | `ENCSR479XDG` (`ENCFF621AIY`) & `ENCSR382HAW` (`ENCFF134PUN`) | K562 Intact/In situ Hi-C (5-kb Knight-Ruiz normalized contact) & 35-biosample average Hi-C | [ENCODE Portal](https://www.encodeproject.org/experiments/ENCSR479XDG/); [Rao et al. (2014)](https://pmc.ncbi.nlm.nih.gov/articles/PMC6690346/) |
| **DNA Methylation (WGBS)** | `ENCSR765JPC` (`ENCFF721JMB`, `ENCFF867JRG`; `GSE86747`) | K562 Whole-Genome Bisulfite Sequencing: focal CpG methylation $M_{\text{focal}}$, 50-kb flanking $M_{\text{bg}}$, CpG count $k_E$, coverage $n_{\text{cov}}$ | [ENCODE Portal](https://www.encodeproject.org/experiments/ENCSR765JPC/); [Burger et al. (2013)](https://pmc.ncbi.nlm.nih.gov/articles/PMC3763559/) |
| **Gene Expression** | `ENCSR000AEM` (`GSE78557`) | K562 PolyA+ RNA-seq (TPM) and promoter ubiquity class across ENCODE biosamples | [ENCODE Portal](https://www.encodeproject.org/experiments/ENCSR000AEM/) |
| **Methylation Perturbation** | `eLife:37513` | K562 Methylation-Sensitive STARR-seq (mSTARR-seq) $\log_2\text{FC}$ (unmethylated vs. M.SssI methylated) | [Lea et al. (2018)](https://elifesciences.org/articles/37513) |

---

## 4. Exact Reproduction Commands

All experiments use deterministic seed `20261025` and run on CPU in ~4 minutes (< 50 MB peak RAM):

```bash
# 1. Build and validate the harmonized K562 multi-omics CRISPRi dataset
python3 src/build_dataset.py

# 2. Run all 5 experimental suites (LOCO CV + 500 locus-clustered bootstrap resamples)
python3 src/run_experiments.py

# 3. Regenerate all figures from saved TSV/JSON outputs in results/
python3 src/generate_figures.py
```

---

## 5. Summary of Key Experimental Results (Held-Out LOCO CV)

| Method / Model | Held-Out AUPRC (95% Locus CI) | AUROC | Precision @ 70% Recall | $\Delta\text{AUPRC}$ vs. `rE2G-Core` | Paired Cluster Bootstrap $p$ |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Baseline A**: Genomic Proximity ($1/d_{EG}$) | 0.2235 [0.1895, 0.2617] | 0.8024 | 0.1349 | $-0.3701$ | $0.0020$ |
| **Baseline B**: 3D Contact Alone (Hi-C KR) | 0.3170 [0.2717, 0.3630] | 0.8585 | 0.1786 | $-0.2771$ | $0.0020$ |
| **Baseline C1**: Naive Methylation + Activity | 0.3957 [0.3482, 0.4434] | 0.9062 | 0.2343 | $-0.1980$ | $0.0020$ |
| **Baseline C2**: PMD-Decoupled Methylation + Activity | 0.4947 [0.4478, 0.5405] | 0.9365 | 0.3374 | $-0.0997$ | $0.0020$ |
| **Baseline D1**: Activity-by-Contact (ABC) | 0.4606 [0.4153, 0.5148] | 0.9291 | 0.3310 | $-0.1323$ | $0.0020$ |
| **Baseline D2**: `ENCODE-rE2G-Core` (Supervised) | 0.5950 [0.5488, 0.6393] | 0.9501 | 0.4148 | Reference ($0.0000$) | $1.0000$ |
| **Ablation 5**: `rE2G-Core` + Naive WGBS ($1 - M_{\text{focal}}$) | 0.5994 [0.5544, 0.6437] | 0.9521 | 0.4174 | $+0.0044$ | $0.3020$ (NS) |
| **Proposed**: **CARA-E2G** (Context-Adjusted Reliability-Aware) | **0.6858** [0.6468, 0.7231] | **0.9656** | **0.5304** | **$+0.0908$** | **$0.0020$** |

**Decision Gate Verdict**: **REFINE** — Context-adjusted, reliability-weighted integration of DNA methylation and 3D chromatin contacts provides a statistically significant, reproducible improvement on held-out chromosomes ($\Delta\text{AUPRC} = +0.0908$, $p = 0.002$, exceeding the pre-registered $+0.015$ threshold), particularly for intermediate/distal enhancers ($25\text{--}500\text{ kb}$, $\Delta\text{AUPRC} = +0.138$) and ubiquitously expressed genes ($\Delta\text{AUPRC} = +0.174$). However, because large-scale CRISPRi validation combined with WGBS and deep Hi-C is currently restricted to K562, cross-cell-type transfer to primary diploid tissues and endogenous dCas9-DNMT3A/TET1 causal dissection are required before claiming universal multi-tissue generalization.
